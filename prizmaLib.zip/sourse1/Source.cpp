#include <iostream>
#include "prizma.h"

using namespace std;

int main() {
	Prizma obj;
	int edges;
	int height;
	int vertices ;
	cout << "enter length edges, height, vertices: ";
	cin >> edges;
	cin >> height;
	cin >> vertices;
	obj.setEdges(edges);
	obj.setHeight(height);
	obj.setVertices(vertices);
	obj.prizmaSizeCalculate();
	obj.prizmaAreaCalculate();
	obj.show();
}