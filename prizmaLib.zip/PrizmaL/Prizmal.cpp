#include "prizma.h"
#include <iostream>
#include <math.h>

using namespace std;

Prizma::Prizma() : edges(0), size(0), area(0), vertices(0), height() {}

Prizma::Prizma(int ed, int si, int ar, int ve, int hi) : edges(ed), size(si), area(ar), vertices(ve), height(hi){}

Prizma::Prizma(const Prizma& other) {
	edges = other.edges;
	size = other.size;
	area = other.area;
	height = other.height;
	vertices = other.vertices;
}

int Prizma::getEdges() const { return edges; }

int Prizma::getSize() const { return size; }

int Prizma::getArea() const { return area; }

int Prizma::getHeight() const { return height; }

int Prizma::getVertices() const { return vertices; }

void Prizma::setEdges(int newEdges) { edges = newEdges; }

void Prizma::setSize(int newSize) { size = newSize; }

void Prizma::setArea(int newArea) { area = newArea; }

void Prizma::setHeight(int newHeight) { area = newHeight; }

void Prizma::setVertices(int newVertices) { vertices = newVertices; }


void Prizma::prizmaSizeCalculate() {
	size = height * (((vertices * edges) / 4) * (1 / (tan(180) / vertices)));
	cout << "Size of the Prizma:"  << size << endl;
}

void Prizma::prizmaAreaCalculate() {
	area = 2 * (((vertices * edges) / 4) * (1 / (tan(180) / vertices ))) + (vertices * height);
	cout << "Area of the Prizma:" << area<< endl;
}

void Prizma::show() {
	cout << "Number of vertices in a Prizma: "<< vertices << endl;
	cout << "Prizma edge length: " << edges << endl;
	cout << "Prizma height: " << height << endl;
	cout << "Prizma size: " << size << endl;
	cout << "Prizma area: " << area << endl;
}

Prizma::~Prizma() {};