#pragma once
using namespace std;

class Prizma {
private:
	int edges;
	int size;
	int area;
	int vertices;
	int height;
public:
	Prizma();

	Prizma(int ed, int si, int ar, int ve, int le);

	Prizma(const Prizma& other);

	int getEdges() const;

	int getSize() const;

	int getArea() const;

	int getHeight() const;

	int getVertices() const;

	void setEdges(int newEdges);

	void setSize(int newSize);

	void setArea(int newArea);

	void setHeight(int newHeight);

	void setVertices(int newVertices);

	void prizmaSizeCalculate();

	void prizmaAreaCalculate();

	void show();

	~Prizma();
};